#!/system/bin/sh
# Usage: run from the extracted gapps directory; set PRIV_APP=1 for system installs.

if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    echo "Usage: [PRIV_APP=1] ./install.sh"
    exit 0
fi

cd "$(dirname "$0")" || exit 2
if ! md5sum -c md5sums.txt >/dev/null 2>&1; then
    while IFS=' ' read -r expected file; do
        [ -n "$file" ] || continue
        actual=$(md5sum "$file" 2>/dev/null) || {
            echo "VERIFY_FAIL $file"
            exit 2
        }
        [ "${actual%% *}" = "$expected" ] || {
            echo "VERIFY_FAIL $file"
            exit 2
        }
    done < md5sums.txt
    echo "VERIFY_FAIL md5sums.txt"
    exit 2
fi

LOG="$(pwd)/install.log"
: > "$LOG" 2>/dev/null || LOG=/dev/null
ok=0
fail=0
PRIV_APP=${PRIV_APP:-0}

install_one() {
    apk=$1
    pkg=$2
    name=$3
    if [ "$PRIV_APP" = "1" ]; then
        mount -o rw,remount /system || mount -o rw,remount / || return 1
        target=/system/priv-app/$name
        mkdir -p "$target" || return 1
        cp "./app/$apk" "$target/$name.apk" || return 1
        chmod 644 "$target/$name.apk" || return 1
        chown 0:0 "$target/$name.apk" || return 1
        if command -v restorecon >/dev/null 2>&1; then
            restorecon -R "$target" || return 1
        fi
        echo "PRIV_OK $name"
    elif pm install -r -g "./app/$apk"; then
        echo "INSTALL_OK $pkg" >> "$LOG"
    else
        echo "INSTALL_FAIL $pkg" >> "$LOG"
        return 1
    fi
}

for entry in \
    'PrebuiltGmsCore.apk com.google.android.gms PrebuiltGmsCore' \
    'Phonesky.apk com.android.vending Phonesky' \
    'GoogleServicesFramework.apk com.google.android.gsf GoogleServicesFramework'
do
    set -- $entry
    if install_one "$1" "$2" "$3"; then
        ok=$((ok + 1))
    else
        [ "$PRIV_APP" = "1" ] && echo "PRIV_FAIL $3"
        fail=$((fail + 1))
    fi
done

echo "DONE ok=$ok fail=$fail"
[ "$fail" -eq 0 ] || exit 3
